
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class MainController {
	@FXML
	private Label statuslabel;
	
	@FXML
	private TextField username;
	
	@FXML
	private TextField password;
	
	public void login(ActionEvent event){
		if(username.getText().equals("user") && password.getText().equals("pass")) {
			statuslabel.setText("Login Sucess");
		} else {
			statuslabel.setText("login failed");
		}
	}
}
