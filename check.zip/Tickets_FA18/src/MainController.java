
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class MainController {
	// create instance fields for class
		private JFrame mainFrame;
		private JLabel headerLabel;
		private JLabel statusLabel;
		private JLabel namelabel;
		private JLabel passwordLabel;
		private JTextField userText;
		private JPasswordField passwordText;
		private JButton loginButton;
		private JPanel controlPanel;
	
	
	@FXML
	private Label statuslabel;
	
	@FXML
	private TextField username;
	
	@FXML
	private TextField password;
	
	public void login(ActionEvent event){
		

		// instantiate controls
				String userName = username.getText();
				// convert characters from password field to string for input validation
				String pass = new String(password.getText());
				statuslabel.setText("hello");
				boolean adminFlag = false;
				
				if (userName.equals("admin") && pass.equals("admin")) {
					System.out.println("username" + userName);
					System.out.println("pass" + pass);
					System.out.println("admin checked");
					adminFlag = true;
					System.out.println("flag = true");
					statuslabel.setText("Login Sucess");
					System.out.println("Login Sucess label");
					// close of Login window
					Platform.exit();
					System.out.println("exit platform");
					// open up ticketsGUI file upon successful login
					System.out.println("enter ticketgui");
					new ticketsGUI("Admin"); // establish role as admin via constructor call
				}
				/*
				 * match credentials from text fields with users table for a
				 * match for regular users
				 */
		
				else if (!adminFlag) {
				
					Connection connect = Dao.getConnection();
				    String queryString = "SELECT uname, upass FROM jjw1_users where uname=? and upass=?";
					java.sql.PreparedStatement ps;
					ResultSet results = null;
					try {
						// set up prepared statements to execute query string cleanly and safely
						ps = (java.sql.PreparedStatement) connect.prepareStatement(queryString);
						ps.setString(1, userName);
						ps.setString(2, pass);
						results = ps.executeQuery();
						if (results.next()) {   // verify if a record match exists
							JOptionPane.showMessageDialog(null, "Username and Password exists");
							// close of Login window
							Platform.exit();
							// open up ticketsGUI file upon successful login
							new ticketsGUI(userName);   // establish role as
														// regular user via
														// constructor call
						} else {
							JOptionPane.showMessageDialog(null, "Wrong Username or Password ");
							statuslabel.setText("login failed");
						}
					} catch (SQLException e1) {
						e1.printStackTrace();
					} finally {
						try {
							results.close();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
						try {
							connect.close();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					}
				}
			
		
		
	}
	
	


}

	
	
	

